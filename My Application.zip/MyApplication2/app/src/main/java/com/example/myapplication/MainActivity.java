package com.example.myapplication;


import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.example.myapplication.Adapter.ToBuildAdapter;
import com.example.myapplication.Model.ToBuildModel;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        getSupportActionBar().hide();

        List<ToBuildModel> habitList = new ArrayList<>();

        RecyclerView habitsRecyclerView = findViewById(R.id.habitsRecyclerView);
        habitsRecyclerView.setLayoutManager(new LinearLayoutManager(this)); // Changed context:this to this

        ToBuildAdapter habitsAdapter = new ToBuildAdapter(this, habitList); // Pass this as the activity and habitList to the adapter
        habitsRecyclerView.setAdapter(habitsAdapter);

        ToBuildModel habit = new ToBuildModel();
        habit.setHabit("This is a test Habit");
        habit.setStatus(0);
        habit.setId(1);

        // Add the habit to the list five times
        for (int i = 0; i < 5; i++) {
            habitList.add(habit);
        }

        habitsAdapter.setHabits(habitList); // Pass the habitList directly

    }
}