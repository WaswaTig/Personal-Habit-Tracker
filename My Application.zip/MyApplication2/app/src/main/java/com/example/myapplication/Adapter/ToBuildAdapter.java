package com.example.myapplication.Adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.myapplication.MainActivity;
import com.example.myapplication.Model.ToBuildModel;
import com.example.myapplication.R;

import java.util.List;

public class ToBuildAdapter extends RecyclerView.Adapter<ToBuildAdapter.ViewHolder> {
    private List<ToBuildModel> tobuildList;

    public ToBuildAdapter(MainActivity activity, List<ToBuildModel> tobuildList) {
        this.tobuildList = tobuildList;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.habits_layout, parent, false);
        return new ViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        ToBuildModel item = tobuildList.get(position);
        holder.habit.setText(item.getHabit());
        holder.habit.setChecked(toBoolean(item.getStatus()));
    }

    @Override
    public int getItemCount() {
        return tobuildList.size();
    }

    private boolean toBoolean(int n) {
        return n != 0;
    }

    public void setHabits(List<ToBuildModel> tobuildList) {
        this.tobuildList = tobuildList;
        notifyDataSetChanged(); // Notify the adapter that the dataset has changed
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        CheckBox habit;

        public ViewHolder(View view) {
            super(view);
            habit = view.findViewById(R.id.goCheckB);
        }
    }
}